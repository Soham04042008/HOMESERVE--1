package com.homeserve.controller;

import com.homeserve.model.*;
import com.homeserve.repository.*;
import com.homeserve.service.SessionTokenService;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
public class ReviewController {
    private final BookingRepository bookings; private final BookingReviewRepository reviews; private final UserRepository users; private final SessionTokenService tokens;
    public ReviewController(BookingRepository b, BookingReviewRepository r, UserRepository u, SessionTokenService t){bookings=b;reviews=r;users=u;tokens=t;}

    @PostMapping("/api/bookings/{bookingId}/review")
    public ResponseEntity<?> submit(@RequestHeader(value="Authorization", required=false) String auth, @PathVariable Long bookingId, @RequestBody Map<String,Object> body){
        Long caller=tokens.userIdFromAuthorization(auth); if(caller==null)return ResponseEntity.status(401).body(Map.of("message","Please sign in again."));
        Booking b=bookings.findById(bookingId).orElse(null); if(b==null)return ResponseEntity.status(404).body(Map.of("message","Booking not found."));
        if(!Objects.equals(caller,b.getUser().getId()))return ResponseEntity.status(403).body(Map.of("message","Only the customer who made this booking can review it."));
        if(!"COMPLETED".equalsIgnoreCase(b.getStatus()))return ResponseEntity.badRequest().body(Map.of("message","You can review a booking only after it is completed."));
        int rating; try { rating=((Number)body.get("rating")).intValue(); } catch(Exception ex){return ResponseEntity.badRequest().body(Map.of("message","Rating must be between 1 and 5."));}
        if(rating<1||rating>5)return ResponseEntity.badRequest().body(Map.of("message","Rating must be between 1 and 5."));
        String comment=Objects.toString(body.get("comment"),"").trim(); if(comment.isEmpty()||comment.length()>1200)return ResponseEntity.badRequest().body(Map.of("message","Review must contain 1 to 1200 characters."));
        BookingReview r=reviews.findByBookingId(bookingId).orElseGet(BookingReview::new);
        r.setBookingId(bookingId);
        r.setCustomerId(caller);
        r.setCustomerName(users.findById(caller).map(AppUser::getFullName).filter(n -> n != null && !n.isBlank()).orElse("Customer"));
        r.setWorkerId(b.getWorkerId());
        r.setServiceName(b.getService() != null && b.getService().getName() != null && !b.getService().getName().isBlank() ? b.getService().getName() : "Home service");
        r.setRating(rating);
        r.setComment(comment);
        return ResponseEntity.status(HttpStatus.CREATED).body(reviewMap(reviews.save(r)));
    }

    @GetMapping("/api/bookings/{bookingId}/review")
    public ResponseEntity<?> bookingReview(@RequestHeader(value="Authorization", required=false) String auth, @PathVariable Long bookingId){
        Long caller=tokens.userIdFromAuthorization(auth); if(caller==null)return ResponseEntity.status(401).body(Map.of("message","Please sign in again."));
        Booking b=bookings.findById(bookingId).orElse(null); if(b==null)return ResponseEntity.status(404).body(Map.of("message","Booking not found."));
        if(!Objects.equals(caller,b.getUser().getId())&&!Objects.equals(caller,b.getWorkerId()))return ResponseEntity.status(403).body(Map.of("message","You cannot view this review."));
        return reviews.findByBookingId(bookingId).<ResponseEntity<?>>map(r->ResponseEntity.ok(reviewMap(r))).orElseGet(()->ResponseEntity.noContent().build());
    }

    @GetMapping("/api/workers/{workerId}/reviews")
    public ResponseEntity<?> publicWorkerReviews(@PathVariable Long workerId){return ResponseEntity.ok(reviews.findByWorkerIdOrderByCreatedAtDesc(workerId).stream().map(this::reviewMap).toList());}

    @GetMapping("/api/workers/me/reviews")
    public ResponseEntity<?> workerReviews(@RequestHeader(value="Authorization", required=false) String auth){
        Long caller=tokens.userIdFromAuthorization(auth); AppUser u=caller==null?null:users.findById(caller).orElse(null);
        if(u==null||!"WORKER".equalsIgnoreCase(u.getRole()))return ResponseEntity.status(401).body(Map.of("message","Worker login required."));
        return ResponseEntity.ok(reviews.findByWorkerIdOrderByCreatedAtDesc(caller).stream().map(this::reviewMap).toList());
    }

    public Map<String,Object> reviewMap(BookingReview r){
        Booking b=bookings.findById(r.getBookingId()).orElse(null); AppUser customer=users.findById(r.getCustomerId()).orElse(null);
        Map<String,Object> m=new LinkedHashMap<>();
        m.put("id",r.getId()); m.put("bookingId",r.getBookingId()); m.put("workerId",r.getWorkerId());
        m.put("customerId",r.getCustomerId());
        m.put("customerName",r.getCustomerName()!=null&&!r.getCustomerName().isBlank()?r.getCustomerName():(customer==null?"Customer":customer.getFullName()));
        m.put("rating",r.getRating()); m.put("comment",r.getComment());
        m.put("serviceName",r.getServiceName()!=null&&!r.getServiceName().isBlank()?r.getServiceName():(b==null||b.getService()==null?"Home service":b.getService().getName()));
        m.put("createdAt",r.getCreatedAt());
        return m;
    }
}
